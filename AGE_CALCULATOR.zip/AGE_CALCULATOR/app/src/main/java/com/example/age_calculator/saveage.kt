package com.example.age_calculator

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.view.View
import android.view.animation.AnimationUtils
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.saveage.*
import kotlinx.android.synthetic.main.saveage.btn_view

class saveage : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.saveage)
        val sharedPreferences: SharedPreferences = this.getSharedPreferences("mypref",Context.MODE_PRIVATE)
        val iName = findViewById<EditText>(R.id.editTextTextPersonName)
        val iDate = findViewById<EditText>(R.id.textView14)
        val iEvent = findViewById<EditText>(R.id.editTextTextPersonName2)

        val oName = findViewById<TextView>(R.id.tvName)
        val oDate = findViewById<TextView>(R.id.tvDate)
        val oEvent = findViewById<TextView>(R.id.tvEvent)
        done_btn.setOnClickListener {

            var n:String = iName.text.toString()
            var d:String = iDate.text.toString()
            var e:String = iEvent.text.toString()


            val editor:SharedPreferences.Editor =  sharedPreferences.edit()
            editor.putString("name_key",n)
            editor.putString("date_key",d)
            editor.putString("event_key",e)
            editor.apply()

            Toast.makeText(this, " date saved", Toast.LENGTH_SHORT).show()

            val img = findViewById<ImageView>(R.id.btn_view)

            var an = AnimationUtils.loadAnimation(this, R.anim.spin)
            img.startAnimation(an)
        }
        btn_view.setOnClickListener{
            val sName = sharedPreferences.getString("name_key","default name")
            val sDate = sharedPreferences.getString("date_key","default date")
            val sEvent = sharedPreferences.getString("event_key","default event")

            oName.setText(sName).toString()
            oDate.setText(sDate).toString()
            oEvent.setText(sEvent).toString()
            cView.visibility = View.VISIBLE
        }







    }

}

