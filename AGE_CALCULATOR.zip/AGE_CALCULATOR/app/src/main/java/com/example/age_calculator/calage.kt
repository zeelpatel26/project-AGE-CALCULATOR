package com.example.age_calculator

import android.app.DatePickerDialog
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.widget.*
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.cal_age.*
import java.text.SimpleDateFormat
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter


class calage : AppCompatActivity() {


    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.cal_age)



        save_btn.setOnClickListener {

            val intent = Intent(applicationContext, saveage::class.java)
            startActivity(intent)
            Toast.makeText(this, "save date here", Toast.LENGTH_SHORT).show()
        }




        // today's date
        val current = LocalDateTime.now()

        val formatter = DateTimeFormatter.ISO_DATE
        val formatted = current.format(formatter)

        today_dt.text = formatted

        //fetch  date year month

        val currentDate = SimpleDateFormat("dd").format(System.currentTimeMillis()).toInt()
        val currentMonth = SimpleDateFormat("mm").format(System.currentTimeMillis()).toInt()
        val currentYear = SimpleDateFormat("yyyy").format(System.currentTimeMillis()).toInt()

        var tv : TextView = findViewById(R.id.DOB_tv)

        fun age(year: Int, month: Int, dayOfMonth: Int): String {
            var modCurrentDate = currentDate
            var modCurrentMonth = currentMonth
            var modCurrentYear = currentYear

            val ageDay: Int
            val ageMonth: Int
            val ageYear: Int

            if (dayOfMonth > modCurrentDate)
            {
                modCurrentDate += 30
                modCurrentMonth -= 1
                ageDay = modCurrentDate - dayOfMonth
            }
            else
            {
                ageDay = modCurrentDate - dayOfMonth
            }

            if (month > modCurrentMonth)
            {
                modCurrentMonth += 12
                modCurrentYear -= 1
                ageMonth = modCurrentMonth - month
            }
            else
            {
                ageMonth = modCurrentMonth - month
            }

            ageYear = modCurrentYear - year

            return ageYear.toString() + "  years  " + ageMonth.toString() + "  months  " + ageDay.toString() + "  days"
        }


            var DPD = DatePickerDialog(this,DatePickerDialog.OnDateSetListener { view, year, month, dayOfMonth ->
            textView5.text = age(year , month , dayOfMonth)

            var selectedDate = "$year-${month + 1}-$dayOfMonth"

            var textView1 = findViewById<TextView>(R.id.dob_tv)
            textView1.text = selectedDate

        },currentYear , currentMonth , currentDate )

        tv.setOnClickListener{
            DPD.show()
        }



    }

}



