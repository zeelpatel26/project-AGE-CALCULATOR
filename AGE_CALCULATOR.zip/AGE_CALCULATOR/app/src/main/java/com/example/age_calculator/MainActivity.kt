package com.example.age_calculator


import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.animation.AnimationUtils
import android.widget.ImageView
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*



class MainActivity : AppCompatActivity(), ConnectivityReceiver.ConnectivityReceiverListener {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        registerReceiver(ConnectivityReceiver(),
            IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION)
        )


            val img = findViewById<ImageView>(R.id.imageView2)

            var an = AnimationUtils.loadAnimation(this, R.anim.spin)
            img.startAnimation(an)

            textView.setOnClickListener {
            val intent = Intent(applicationContext, calage::class.java)
            startActivity(intent)
            Toast.makeText(this, "calculate age", Toast.LENGTH_SHORT).show()
        }

    }

    override fun onNetworkConnectionChanged(isConnected: Boolean) {
        showNetworkMessage(isConnected)
    }

    override fun onResume() {
        super.onResume()
        ConnectivityReceiver.connectivityReceiverListener = this
    }

    private fun showNetworkMessage(isConnected: Boolean) {
        if (!isConnected) {
            Toast.makeText(applicationContext,"You are offline",Toast.LENGTH_LONG).show()
        }
        else { Toast.makeText(applicationContext,"You are online",Toast.LENGTH_LONG).show()}
    }
}



